<?php

class InvalidProvider
{
}
