#Create the Underlying DB Tables for Sentinel

Sentinel requires just a few tables to run properly.

Some frameworks will preconfigure the Sentinel implementation.

If yours does not or for whatever reason you need to install manually:

Run or source mysql.sql for MySQL 5.5.x and below & forks of similar code base

Run or source mysql-5.6+.sql for MySQL 5.6.x and up & forks of similar code base 
